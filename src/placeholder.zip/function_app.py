import azure.functions as func

app = func.FunctionApp()

@app.function_name(name='placeholder-zip')
@app.event_grid_trigger(arg_name='event')
def main(event: func.EventGridEvent):
    pass